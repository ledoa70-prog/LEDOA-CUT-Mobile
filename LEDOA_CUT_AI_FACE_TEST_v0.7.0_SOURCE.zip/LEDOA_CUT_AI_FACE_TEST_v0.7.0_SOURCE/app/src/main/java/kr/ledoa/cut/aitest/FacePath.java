package kr.ledoa.cut.aitest;

import java.util.*;

/** No Android dependency. Geometry is normalized to the ORIGINAL ROTATED bitmap orientation. */
public final class FacePath {
    public enum Status { TRACKED, UNCERTAIN, LOST, VERIFIED }
    public static final class Box {
        public final float x,y,w,h;
        public final int id;
        public Box(float x, float y,float w,float h,int id) {
            this.x=x;this.y=y;this.w=w;this.h=h;this.id=id;
        }
        public float cx(){return x+w/2f;}
        public float cy(){return y+h/2f;}
        public float area(){return w*h;}
        public float dist(Box b) {return (float)Math.hypot(cx()-b.cx(),cy()-b.cy());}
        public boolean contains(float u,float v){return u>=x&&u<=x+w&&v>=y&&v<=y+h;}
        public Box expanded(float margin){
            float xx=Math.max(0,x-w*margin),yy=Math.max(0,y-h*margin);
            float x2=Math.min(1,x+w*(1+margin)),y2=Math.min(1,y+h*(1+margin));
            return new Box(xx,yy,x2-xx,y2-yy,id);
        }
    }
    public static final class Point {
        public final long ms; public final Box box; public final Status status;
        public Point(long ms,Box box,Status status){this.ms=ms;this.box=box;this.status=status;}
    }
    public static final class Pick {
        public final Box box; public final Status status;
        Pick(Box box, Status status){this.box=box;this.status=status;}
    }
    private final TreeMap<Long,Point> frames=new TreeMap<>();
    private Box last; private int lastId=-1; private long lastMs=-1;
    public synchronized void reset(){frames.clear();last=null;lastId=-1;lastMs=-1;}
    public synchronized void anchor(long ms,Box box){
        Objects.requireNonNull(box);
        frames.tailMap(ms,true).clear();
        last=box;lastId=box.id;lastMs=ms;frames.put(ms,new Point(ms,box,Status.VERIFIED));
    }
    public synchronized Point step(long ms,List<Box> found){
        if(last==null)throw new IllegalStateException("Select face before tracking");
        if(ms<=lastMs)throw new IllegalArgumentException("Samples must be forward and strictly increasing");
        Pick p=choose(last,lastId,Math.max(1,ms-lastMs),found);
        Point out=new Point(ms,p.box,p.status);frames.put(ms,out);
        // Never jump to another face or advance a lost track's anchor.
        if(p.status==Status.TRACKED){last=p.box;lastId=p.box.id;lastMs=ms;}
        return out;
    }
    public synchronized void review(long ms,Box box){
        // A manual correction is a new anchor. The future path needs rescanning.
        anchor(ms,box);
    }
    public synchronized List<Point> points(){return new ArrayList<>(frames.values());}
    public synchronized int reviewCount(){int n=0;for(Point p:frames.values())if(p.status!=Status.TRACKED && p.status!=Status.VERIFIED)n++;return n;}
    public synchronized Point nearest(long ms){
        Map.Entry<Long,Point> f=frames.floorEntry(ms),c=frames.ceilingEntry(ms);
        if(f==null)return c==null?null:c.getValue();
        if(c==null)return f.getValue();
        return ms-f.getKey()<=c.getKey()-ms?f.getValue():c.getValue();
    }
    public synchronized Point interpolated(long ms){
        Map.Entry<Long,Point> a=frames.floorEntry(ms),b=frames.ceilingEntry(ms);
        if(a==null||b==null)return null;
        Point p=a.getValue(),q=b.getValue();
        if(p.box==null||q.box==null)return null;
        // Conservative: do not interpolate across missing or ambiguous detections.
        if(p.status==Status.LOST||p.status==Status.UNCERTAIN||q.status==Status.LOST||q.status==Status.UNCERTAIN)return null;
        if(q.ms-p.ms>160)return null;
        if(q.ms==p.ms)return p;
        float t=(float)(ms-p.ms)/(q.ms-p.ms);
        Box x=p.box,y=q.box;
        return new Point(ms,new Box(lerp(x.x,y.x,t),lerp(x.y,y.y,t),lerp(x.w,y.w,t),lerp(x.h,y.h,t),y.id),Status.TRACKED);
    }
    private static float lerp(float a,float b,float t){return a+(b-a)*t;}

    /** Reject teleports and ambiguous crossings rather than switching a different person's face. */
    public static Pick choose(Box previous,int previousId,long deltaMs,List<Box> candidates){
        if(candidates==null||candidates.isEmpty())return new Pick(null,Status.LOST);
        double best=Double.POSITIVE_INFINITY,second=Double.POSITIVE_INFINITY; Box winner=null;
        double maxStep=Math.min(.16,.04+.00023*Math.min(deltaMs,300));
        for(Box b:candidates){
            double distance=previous.dist(b);
            double relArea=Math.max(.01,b.area())/Math.max(.01,previous.area());
            if(distance>maxStep||relArea<.38||relArea>2.7)continue;
            double shape=Math.abs(Math.log(relArea))*.055;
            double idPenalty= previousId>=0 && b.id>=0 && previousId!=b.id ? .075:0;
            double score=distance+shape+idPenalty;
            if(score<best){second=best;best=score;winner=b;}
            else if(score<second)second=score;
        }
        if(winner==null)return new Pick(null,Status.LOST);
        // If two faces overlap in position, even a matching ID is not enough.
        for(Box b:candidates) {
            if(b!=winner && b.dist(winner)<Math.max(.05f,Math.min(winner.w,winner.h)*.65f))
                return new Pick(null,Status.UNCERTAIN);
        }
        if(second-best<.03 || best>.18)return new Pick(null,Status.UNCERTAIN);
        return new Pick(winner,Status.TRACKED);
    }
}
