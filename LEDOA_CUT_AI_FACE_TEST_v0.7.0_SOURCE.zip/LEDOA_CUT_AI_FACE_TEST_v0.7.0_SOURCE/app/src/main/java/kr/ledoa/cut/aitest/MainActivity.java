package kr.ledoa.cut.aitest;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Independent feasibility test only. DOES NOT change LEDOA CUT, DOES NOT export MP4.
 * It intentionally refuses to silently mask lost detections or claim an unverified video is safe.
 */
public final class MainActivity extends Activity {
    private static final int PICK_VIDEO=1001, SAVE_TRACK=1002;
    private static final long STEP_MS=100; // 10 fps feasibility analysis, not release-grade 30 fps.
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean cancel=new AtomicBoolean(false);
    private final AtomicInteger generation=new AtomicInteger(0);
    private final FacePath path=new FacePath();
    private FaceDetector detector;
    private MediaMetadataRetriever retriever;
    private Uri videoUri;
    private long durationMs=0,currentMs=0,anchorMs=-1;
    private volatile boolean analysing=false;
    private FacePath.Box selected;
    private List<FacePath.Box> visibleFaces=new ArrayList<>();
    private FrameView frameView;
    private TextView status,clock,disclaimer;
    private SeekBar seek;
    private Button openBtn,trackBtn,cancelBtn,saveBtn;
    private boolean updatingSeek=false;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(13,19,27));
        getWindow().setNavigationBarColor(Color.rgb(13,19,27));
        FaceDetectorOptions opts=new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
                .enableTracking().setMinFaceSize(.045f).build();
        detector=FaceDetection.getClient(opts);
        renderUi();
    }
    private TextView text(String message,int size,int color){
        TextView t=new TextView(this);t.setText(message);t.setTextSize(size);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(8),dp(5),dp(8),dp(5));return t;
    }
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private Button btn(String label){Button x=new Button(this);x.setText(label);x.setAllCaps(false);x.setTextSize(13);return x;}
    private void renderUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(13,19,27));root.setPadding(dp(10),dp(6),dp(10),dp(6));
        root.addView(text("LEDOA CUT  |  AI 얼굴 모자이크 TEST 0.7.0",18,Color.WHITE));
        root.addView(text("정식 앱과 분리 · 선택한 얼굴 1명 · 픽셀화 강도 85%",12,Color.rgb(188,199,215)));
        frameView=new FrameView();root.addView(frameView,new LinearLayout.LayoutParams(-1,0,1));frameView.setMinimumHeight(dp(150));
        clock=text("00:00.0 / 00:00.0",12,Color.WHITE);root.addView(clock);
        seek=new SeekBar(this);seek.setMax(1000);root.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int value,boolean fromUser){if(fromUser && durationMs>0) clock.setText(fmt(durationMs*value/1000)+" / "+fmt(durationMs));}
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){if(!analysing && durationMs>0){long target=durationMs*s.getProgress()/1000; if(target!=anchorMs){selected=null;anchorMs=-1;} preview(target);}}
        });
        LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);
        openBtn=btn("영상 불러오기");trackBtn=btn("선택 얼굴 추적");cancelBtn=btn("중단");saveBtn=btn("추적 데이터 저장");
        for(Button button:new Button[]{openBtn,trackBtn,cancelBtn})buttons.addView(button,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(buttons);root.addView(saveBtn,new LinearLayout.LayoutParams(-1,dp(45)));
        status=text("영상 불러오기 → 얼굴이 보이는 곳에서 일시정지 → 얼굴 터치 → 추적",13,Color.rgb(244,204,112));
        root.addView(status);
        disclaimer=text("독립 검증용: 모자이크 미리보기만 제공합니다. MP4 내보내기는 누락 프레임 검사 후 연결합니다.",11,Color.rgb(181,189,200));root.addView(disclaimer);
        setContentView(root);
        openBtn.setOnClickListener(v->pickVideo());
        trackBtn.setOnClickListener(v->startAnalysis());
        cancelBtn.setOnClickListener(v->{cancel.set(true);status.setText("중단 요청 중…");});
        saveBtn.setOnClickListener(v->saveTrack());
        controls();
    }
    private void controls(){
        openBtn.setEnabled(!analysing);trackBtn.setEnabled(!analysing && selected!=null);
        cancelBtn.setEnabled(analysing);saveBtn.setEnabled(!analysing && !path.points().isEmpty());
        seek.setEnabled(!analysing && durationMs>0);
    }
    private String fmt(long m){return String.format(Locale.KOREA,"%02d:%02d.%01d",m/60000,(m/1000)%60,(m/100)%10);}
    private void pickVideo(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,PICK_VIDEO);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null)return;
        if(request==SAVE_TRACK){writeTrack(data.getData());return;}
        if(request!=PICK_VIDEO)return;
        Uri uri=data.getData();if(uri==null)return;
        generation.incrementAndGet();cancel.set(true);
        status.setText("영상 정보를 읽는 중…");
        worker.execute(()->{
            try{
                MediaMetadataRetriever r=new MediaMetadataRetriever();r.setDataSource(this,uri);
                String duration=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                long ms=Long.parseLong(duration==null?"0":duration);
                if(ms<=0)throw new IllegalArgumentException("영상 길이를 읽지 못했습니다.");
                MediaMetadataRetriever old=retriever;retriever=r;
                if(old!=null)old.release();videoUri=uri;
                durationMs=ms;currentMs=0;anchorMs=-1;selected=null;path.reset();
                runOnUiThread(()->{status.setText("원하는 얼굴을 터치해 주세요.");controls();});
                preview(0);
            }catch(Exception e){runOnUiThread(()->status.setText("영상 열기 실패: "+e.getMessage()));}
        });
    }
    private Bitmap bitmapAt(long ms){
        if(retriever==null)return null;
        // This returns a displayed-rotation bitmap on supported Android implementations.
        // All face coordinates are normalized against the ACTUAL bitmap dimensions.
        return retriever.getScaledFrameAtTime(Math.max(0,ms)*1000,MediaMetadataRetriever.OPTION_CLOSEST,960,960);
    }
    private List<FacePath.Box> detect(Bitmap frame)throws Exception {
        List<FacePath.Box> boxes=new ArrayList<>();if(frame==null)return boxes;
        List<Face> faces=Tasks.await(detector.process(InputImage.fromBitmap(frame,0)));
        for(Face face:faces){Rect r=face.getBoundingBox();
            float x=clamp(r.left/(float)frame.getWidth()),y=clamp(r.top/(float)frame.getHeight());
            float right=clamp(r.right/(float)frame.getWidth()),bottom=clamp(r.bottom/(float)frame.getHeight());
            if(right>x&&bottom>y)boxes.add(new FacePath.Box(x,y,right-x,bottom-y,face.getTrackingId()==null?-1:face.getTrackingId()));
        }return boxes;
    }
    private float clamp(float n){return Math.max(0,Math.min(1,n));}
    private void preview(long ms){
        if(retriever==null)return;
        int token=generation.incrementAndGet();currentMs=Math.min(durationMs,Math.max(0,ms));
        worker.execute(()->{
            if(analysing||token!=generation.get())return;
            Bitmap frame=null;
            try{
                frame=bitmapAt(currentMs);
                List<FacePath.Box> boxes=detect(frame);
                if(token!=generation.get()){if(frame!=null)frame.recycle();return;}
                Bitmap result=frame;long shown=currentMs;
                runOnUiThread(()->{
                    if(token!=generation.get()){if(result!=null)result.recycle();return;}
                    visibleFaces=boxes;frameView.setFrame(result,boxes,path.interpolated(shown),path.nearest(shown));
                    updatingSeek=true;seek.setProgress((int)(1000.0*shown/durationMs));updatingSeek=false;
                    clock.setText(fmt(shown)+" / "+fmt(durationMs));
                    status.setText(selected==null?"터치해서 가릴 얼굴을 선택하세요.":"노란 얼굴 상자 선택됨 · 추적 또는 해당 시점에서 재선택 가능");
                    controls();
                });
            }catch(Exception e){if(frame!=null)frame.recycle();runOnUiThread(()->status.setText("프레임 분석 실패: "+e.getMessage()));}
        });
    }
    private void onFaceTap(float u,float v){
        if(analysing||visibleFaces==null)return;
        FacePath.Box picked=null;
        for(FacePath.Box b:visibleFaces)if(b.expanded(.08f).contains(u,v)){
            if(picked==null||b.area()<picked.area())picked=b;
        }
        if(picked==null){status.setText("얼굴 영역 밖입니다. 얼굴 안쪽을 다시 터치하세요.");return;}
        selected=picked;anchorMs=currentMs;
        path.anchor(anchorMs,picked);
        frameView.setFrame(frameView.frame,visibleFaces,path.interpolated(currentMs),path.nearest(currentMs));
        status.setText("선택 완료 · 추적 버튼을 눌러주세요. 다른 시점에서 선택하면 그 이후 경로를 다시 계산합니다.");
        controls();
    }
    private void startAnalysis(){
        if(selected==null||retriever==null||analysing)return;
        final long start=anchorMs,end=Math.min(durationMs,start+30_000);
        final FacePath.Box anchor=selected;
        cancel.set(false);analysing=true;controls();
        status.setText("얼굴 이동 분석 중… (최대 30초)");
        worker.execute(()->{
            try{
                path.anchor(start,anchor);
                int failed=0,total=0;
                for(long ms=start+STEP_MS;ms<=end;ms+=STEP_MS){
                    if(cancel.get())break;
                    Bitmap frame=bitmapAt(ms);
                    List<FacePath.Box> found;
                    try{found=detect(frame);}finally{if(frame!=null)frame.recycle();}
                    FacePath.Point p=path.step(ms,found);total++;
                    if(p.status!=FacePath.Status.TRACKED)failed++;
                    final int index=total,problem=failed;final long processed=ms;
                    if(index%10==0)runOnUiThread(()->status.setText("분석 "+fmt(processed-start)+" / "+fmt(end-start)+" · 확인 필요 프레임: "+problem));
                }
                final int problems=failed;
                final boolean stopped=cancel.get();
                runOnUiThread(()->{
                    analysing=false;controls();
                    status.setText((stopped?"중단됨":"분석 완료")+" · 확인 필요 샘플 "+problems+"개. 노란 표시 구간은 수동 확인하세요. MP4 저장은 비활성화 상태입니다.");
                    preview(start);
                });
            }catch(Exception e){runOnUiThread(()->{analysing=false;controls();status.setText("분석 중 오류: "+e.getMessage());});}
        });
    }
    private void saveTrack(){
        if(path.points().isEmpty())return;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_TITLE,"LEDOA_FACE_TRACK_v0.7.0.json");startActivityForResult(i,SAVE_TRACK);
    }
    private void writeTrack(Uri uri){
        if(uri==null)return;
        try{
            JSONObject obj=new JSONObject();obj.put("schema",1).put("kind","preview-test-only");
            obj.put("strength",85).put("opacity",100).put("frameStepMs",STEP_MS).put("durationMs",durationMs);
            obj.put("reviewCount",path.reviewCount()); // Do not disclose device-local document URIs in exported metadata.
            JSONArray arr=new JSONArray();
            for(FacePath.Point p:path.points()){
                JSONObject o=new JSONObject().put("ms",p.ms).put("status",p.status.name());
                if(p.box!=null)o.put("x",p.box.x).put("y",p.box.y).put("w",p.box.w).put("h",p.box.h);
                arr.put(o);
            }obj.put("points",arr);
            try(OutputStream s=getContentResolver().openOutputStream(uri)){
                if(s==null)throw new Exception("출력 스트림 없음");s.write(obj.toString(2).getBytes(StandardCharsets.UTF_8));
            }
            status.setText("좌표 JSON을 저장했습니다. 완성된 모자이크 영상이 아닙니다.");
        }catch(Exception e){status.setText("좌표 저장 실패: "+e.getMessage());}
    }
    @Override protected void onDestroy(){
        cancel.set(true);generation.incrementAndGet();worker.shutdownNow();
        if(retriever!=null)retriever.release();
        if(detector!=null)detector.close();
        super.onDestroy();
    }
    private final class FrameView extends View {
        private Bitmap frame;
        private List<FacePath.Box> faces=new ArrayList<>();
        private FacePath.Point interpolated,nearest;
        private final Paint image=new Paint(Paint.FILTER_BITMAP_FLAG),line=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pixel=new Paint();
        private final RectF display=new RectF();
        FrameView(){super(MainActivity.this);setBackgroundColor(Color.BLACK);pixel.setFilterBitmap(false);pixel.setAntiAlias(false);}
        void setFrame(Bitmap next,List<FacePath.Box> detections,FacePath.Point safe,FacePath.Point close){
            if(next!=null && frame!=next && frame!=null && !frame.isRecycled())frame.recycle();
            frame=next;faces=detections;interpolated=safe;nearest=close;invalidate();
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            if(frame==null||frame.isRecycled()){
                line.setColor(Color.WHITE);line.setTextSize(dp(16));c.drawText("테스트용 영상 불러오기",dp(20),getHeight()/2f,line);return;
            }
            float fw=frame.getWidth(),fh=frame.getHeight();
            float scale=Math.min(getWidth()/fw,getHeight()/fh);
            float w=fw*scale,h=fh*scale,left=(getWidth()-w)/2f,top=(getHeight()-h)/2f;
            display.set(left,top,left+w,top+h);
            c.drawBitmap(frame,null,display,image);
            if(interpolated!=null&&interpolated.box!=null){drawMosaic(c,interpolated.box.expanded(.18f));}
            if(nearest!=null&&(nearest.status==FacePath.Status.LOST||nearest.status==FacePath.Status.UNCERTAIN)){
                line.setColor(Color.YELLOW);line.setTextSize(dp(17));c.drawText("추적 확인 필요",left+dp(14),top+dp(26),line);
            }
            for(FacePath.Box b:faces){
                RectF rect=rectFor(b);line.setStyle(Paint.Style.STROKE);line.setStrokeWidth(dp(1.5f));
                line.setColor(Color.rgb(136,185,224));c.drawRect(rect,line);line.setStyle(Paint.Style.FILL);
            }
            if(selected!=null&&anchorMs==currentMs){
                line.setStyle(Paint.Style.STROKE);line.setColor(Color.YELLOW);line.setStrokeWidth(dp(3));
                c.drawRect(rectFor(selected),line);line.setStyle(Paint.Style.FILL);
            }
        }
        private RectF rectFor(FacePath.Box b){return new RectF(display.left+b.x*display.width(),display.top+b.y*display.height(),display.left+(b.x+b.w)*display.width(),display.top+(b.y+b.h)*display.height());}
        private void drawMosaic(Canvas c,FacePath.Box b){
            Rect crop=new Rect(Math.max(0,(int)(b.x*frame.getWidth())),Math.max(0,(int)(b.y*frame.getHeight())),
                    Math.min(frame.getWidth(),(int)((b.x+b.w)*frame.getWidth())),Math.min(frame.getHeight(),(int)((b.y+b.h)*frame.getHeight())));
            if(crop.width()<2||crop.height()<2)return;
            Bitmap region=null,small=null;
            try{
                region=Bitmap.createBitmap(frame,crop.left,crop.top,crop.width(),crop.height());
                int smallW=Math.max(2,Math.min(9,crop.width()/2));
                int smallH=Math.max(2,(int)Math.round(smallW*crop.height()/(double)crop.width()));
                small=Bitmap.createScaledBitmap(region,smallW,smallH,false);
                c.drawBitmap(small,null,rectFor(b),pixel); // alpha is 100%, pixelation strength = 85.
            }finally{if(small!=null&&small!=region)small.recycle();if(region!=null)region.recycle();}
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getActionMasked()!=MotionEvent.ACTION_UP)return true;
            if(frame==null||!display.contains(e.getX(),e.getY()))return true;
            float u=(e.getX()-display.left)/display.width(),v=(e.getY()-display.top)/display.height();
            onFaceTap(u,v);return true;
        }
    }
}
