import kr.ledoa.cut.aitest.FacePath;
import java.util.*;
public class FacePathTest {
 static void ok(boolean c, String s){if(!c)throw new AssertionError(s);}
 static FacePath.Box b(float x,float y,int id){return new FacePath.Box(x,y,.10f,.13f,id);}
 public static void main(String[] args) {
  FacePath f=new FacePath();
  f.anchor(0,b(.2f,.25f,1));
  ok(f.step(100,List.of(b(.23f,.25f,1),b(.65f,.30f,2))).status==FacePath.Status.TRACKED,"follows selected face");
  ok(f.step(200,List.of(b(.78f,.30f,2))).status==FacePath.Status.LOST,"no teleport to another face");
  ok(f.reviewCount()==1,"lost region reported");
  ok(f.interpolated(150)==null,"do not mask across missing detection");
  f.review(200,b(.27f,.25f,1));
  ok(f.reviewCount()==0,"correction invalidates future");
  ok(f.step(300,List.of(b(.29f,.25f,1))).status==FacePath.Status.TRACKED,"recover after correction");
  f.reset();f.anchor(0,b(.20f,.20f,1));
  ok(f.step(100,List.of(b(.23f,.20f,1),b(.231f,.20f,2))).status==FacePath.Status.UNCERTAIN,"face crossing requires review");
  f.reset();f.anchor(0,b(.20f,.20f,1));
  f.step(100,List.of(b(.22f,.20f,1)));
  ok(f.interpolated(50)!=null,"interpolation within verified interval");
  System.out.println("PASS: 8 FacePath safety checks");
 }
}
