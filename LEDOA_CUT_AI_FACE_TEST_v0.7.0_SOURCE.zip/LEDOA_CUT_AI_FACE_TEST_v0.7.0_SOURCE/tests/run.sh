#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p tests/out
javac -d tests/out app/src/main/java/kr/ledoa/cut/aitest/FacePath.java tests/FacePathTest.java
java -cp tests/out FacePathTest
