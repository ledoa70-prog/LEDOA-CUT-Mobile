# LEDOA CUT Mobile Shorts Standalone v0.6.6 source

This source package preserves the current mobile editor web assets and adds a fully bundled offline face-detection engine for the face-mask tracker.

## v0.6.6 face tracking change
- Removed dependency on a face detector loaded from the network at runtime.
- Bundled the face detector model as `face_haar_data.js` inside the app assets.
- Tapping a face uses a detected tight face rectangle as the tracking anchor.
- Tracking searches around the previous detected face and rejects impossible jumps.
- If the face cannot be detected temporarily, the tracker holds the last valid face box instead of jumping to a screen corner or a different region.
- Existing editor/export/autosave UI assets are carried forward from the v0.6.5 app package.

## Important
This is the rebuildable Android Studio source package. The provided v0.6.5 APK remains the installable build for immediate testing.


## v0.6.6 direct target lock
- Tracking starts directly from the exact tight face box selected by the user.
- Removed the redundant start-frame re-detection that could abort with “selected face not found”.
- Subsequent frames still use local face detection, motion gating, smoothing, and last-valid-box hold to prevent corner jumps.
