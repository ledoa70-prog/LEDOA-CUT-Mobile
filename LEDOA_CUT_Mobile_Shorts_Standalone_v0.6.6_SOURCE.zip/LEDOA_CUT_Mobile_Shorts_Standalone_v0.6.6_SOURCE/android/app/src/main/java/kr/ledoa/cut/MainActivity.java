package kr.ledoa.cut;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 701;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                } catch (Exception ex) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || fileChooserCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(result);
        fileChooserCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class AndroidBridge {
        private final Activity activity;
        private Uri currentUri;
        private OutputStream currentOutput;

        AndroidBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public synchronized void beginFile(String name, String mime, long totalBytes) {
            closeQuietly();
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                Uri collection;
                if (mime != null && mime.startsWith("image/")) {
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/LEDOA CUT");
                    collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if (mime != null && mime.startsWith("video/")) {
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/LEDOA CUT");
                    collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else {
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/LEDOA CUT");
                    collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                }

                currentUri = activity.getContentResolver().insert(collection, values);
                if (currentUri == null) throw new IllegalStateException("저장 위치 생성 실패");
                currentOutput = activity.getContentResolver().openOutputStream(currentUri, "w");
                if (currentOutput == null) throw new IllegalStateException("저장 스트림 생성 실패");
            } catch (Exception e) {
                closeQuietly();
                showToast("저장 시작 실패: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public synchronized void appendChunk(String base64Chunk) {
            if (currentOutput == null || base64Chunk == null) return;
            try {
                byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
                currentOutput.write(bytes);
            } catch (Exception e) {
                showToast("저장 중 오류: " + e.getMessage());
                closeQuietly();
            }
        }

        @JavascriptInterface
        public synchronized void finishFile() {
            if (currentUri == null) return;
            try {
                if (currentOutput != null) {
                    currentOutput.flush();
                    currentOutput.close();
                    currentOutput = null;
                }
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                activity.getContentResolver().update(currentUri, values, null, null);
                showToast("LEDOA CUT 저장 완료");
            } catch (Exception e) {
                showToast("저장 마무리 실패: " + e.getMessage());
            } finally {
                currentUri = null;
                currentOutput = null;
            }
        }

        private synchronized void closeQuietly() {
            try { if (currentOutput != null) currentOutput.close(); } catch (Exception ignored) {}
            currentOutput = null;
            currentUri = null;
        }

        private void showToast(String message) {
            activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
        }
    }
}
