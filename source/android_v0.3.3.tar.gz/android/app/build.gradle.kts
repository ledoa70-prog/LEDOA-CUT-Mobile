plugins { id("com.android.application") }

android {
    namespace = "kr.ledoa.cut"
    compileSdk = 35

    defaultConfig {
        applicationId = "kr.ledoa.cut"
        minSdk = 29
        targetSdk = 35
        versionCode = 33
        versionName = "0.3.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
